package com.example.controlesbasicose6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity
{

    private ImageView imgC1;
    private ImageView imgC2;

    private ImageView imgL1;
    private ImageView imgL2;

    private Switch swtC1;
    private Switch swtL1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgC1=findViewById(R.id.imgC1);

        swtC1=findViewById(R.id.swtC1);
        swtL1=findViewById(R.id.swtL1);
    }

    public void apagarC1(View v)
    {
        if(swtC1.getVisibility()==View.VISIBLE)
            imgC1.setVisibility(View.INVISIBLE);
        else
            imgC1.setVisibility(View.VISIBLE);
    }

    public void controlarLuz(View v)
    {
        ///////////////
    }


}